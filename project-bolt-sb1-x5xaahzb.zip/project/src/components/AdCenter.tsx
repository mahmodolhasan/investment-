import React, { useState, useEffect } from 'react';
import { PlayCircle, PauseCircle } from 'lucide-react';

const AdCenter: React.FC = () => {
  const [timeLeft, setTimeLeft] = useState(30);
  const [isWatching, setIsWatching] = useState(false);
  const [dailyProgress, setDailyProgress] = useState(45);
  const dailyQuota = 50;

  useEffect(() => {
    let timer: number;
    if (isWatching && timeLeft > 0) {
      timer = window.setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setIsWatching(false);
      setTimeLeft(30);
      setDailyProgress((prev) => Math.min(prev + 1, dailyQuota));
    }
    return () => clearInterval(timer);
  }, [isWatching, timeLeft]);

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-2xl font-semibold mb-4">Ad Center</h2>
        
        {/* Progress Bar */}
        <div className="mb-6">
          <div className="flex justify-between mb-2">
            <span className="text-sm font-medium text-gray-700">Daily Progress</span>
            <span className="text-sm font-medium text-gray-700">{dailyProgress}/{dailyQuota}</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div 
              className="bg-blue-600 h-2.5 rounded-full" 
              style={{ width: `${(dailyProgress / dailyQuota) * 100}%` }}
            ></div>
          </div>
        </div>

        {/* Ad Viewer */}
        <div className="bg-gray-100 rounded-lg p-6 text-center">
          {isWatching ? (
            <>
              <div className="mb-4">
                <div className="w-full h-64 bg-gray-300 rounded-lg flex items-center justify-center">
                  <span className="text-2xl text-gray-600">Ad Content</span>
                </div>
              </div>
              <div className="mb-4">
                <span className="text-xl font-semibold">{timeLeft}s remaining</span>
              </div>
              <button
                onClick={() => setIsWatching(false)}
                className="inline-flex items-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
              >
                <PauseCircle className="w-5 h-5 mr-2" />
                Stop Watching
              </button>
            </>
          ) : (
            <button
              onClick={() => setIsWatching(true)}
              className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              disabled={dailyProgress >= dailyQuota}
            >
              <PlayCircle className="w-5 h-5 mr-2" />
              Watch Ad
            </button>
          )}
        </div>
      </div>

      {/* Earnings Summary */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-xl font-semibold mb-4">Today's Earnings</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-green-50 p-4 rounded-lg">
            <p className="text-sm text-gray-600">Ads Watched</p>
            <p className="text-2xl font-bold text-green-600">{dailyProgress}</p>
          </div>
          <div className="bg-blue-50 p-4 rounded-lg">
            <p className="text-sm text-gray-600">Earnings per Ad</p>
            <p className="text-2xl font-bold text-blue-600">$0.10</p>
          </div>
          <div className="bg-purple-50 p-4 rounded-lg">
            <p className="text-sm text-gray-600">Total Earnings</p>
            <p className="text-2xl font-bold text-purple-600">${(dailyProgress * 0.1).toFixed(2)}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdCenter;