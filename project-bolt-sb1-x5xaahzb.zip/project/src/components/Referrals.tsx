import React from 'react';
import { Copy, Share2 } from 'lucide-react';

const Referrals: React.FC = () => {
  const referralLink = 'https://investmlm.com/ref/user123';

  const copyToClipboard = () => {
    navigator.clipboard.writeText(referralLink);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-2xl font-semibold mb-4">Referral Program</h2>
        
        {/* Referral Link */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Your Referral Link
          </label>
          <div className="flex">
            <input
              type="text"
              readOnly
              value={referralLink}
              className="flex-1 rounded-l-lg border border-r-0 border-gray-300 px-4 py-2 bg-gray-50"
            />
            <button
              onClick={copyToClipboard}
              className="px-4 py-2 bg-blue-600 text-white rounded-r-lg hover:bg-blue-700 flex items-center"
            >
              <Copy className="w-4 h-4 mr-2" />
              Copy
            </button>
          </div>
        </div>

        {/* Commission Structure */}
        <div className="bg-gray-50 rounded-lg p-6 mb-6">
          <h3 className="text-lg font-semibold mb-4">Commission Structure</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <p className="font-medium">Level 1 (Direct)</p>
                <p className="text-sm text-gray-600">Your direct referrals</p>
              </div>
              <span className="text-lg font-bold text-green-600">10%</span>
            </div>
            <div className="flex justify-between items-center">
              <div>
                <p className="font-medium">Level 2</p>
                <p className="text-sm text-gray-600">Referrals from your referrals</p>
              </div>
              <span className="text-lg font-bold text-green-600">5%</span>
            </div>
            <div className="flex justify-between items-center">
              <div>
                <p className="font-medium">Level 3</p>
                <p className="text-sm text-gray-600">Third level referrals</p>
              </div>
              <span className="text-lg font-bold text-green-600">3%</span>
            </div>
          </div>
        </div>

        {/* Share Buttons */}
        <div>
          <h3 className="text-lg font-semibold mb-4">Share Your Link</h3>
          <div className="grid grid-cols-2 gap-4">
            <button className="flex items-center justify-center px-4 py-2 bg-[#1DA1F2] text-white rounded-lg hover:bg-[#1a91da]">
              <Share2 className="w-5 h-5 mr-2" />
              Share on Twitter
            </button>
            <button className="flex items-center justify-center px-4 py-2 bg-[#4267B2] text-white rounded-lg hover:bg-[#365899]">
              <Share2 className="w-5 h-5 mr-2" />
              Share on Facebook
            </button>
          </div>
        </div>
      </div>

      {/* Earnings Stats */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-xl font-semibold mb-4">Referral Earnings</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-green-50 p-4 rounded-lg">
            <p className="text-sm text-gray-600">Total Referrals</p>
            <p className="text-2xl font-bold text-green-600">156</p>
          </div>
          <div className="bg-blue-50 p-4 rounded-lg">
            <p className="text-sm text-gray-600">Active Referrals</p>
            <p className="text-2xl font-bold text-blue-600">89</p>
          </div>
          <div className="bg-purple-50 p-4 rounded-lg">
            <p className="text-sm text-gray-600">Total Earnings</p>
            <p className="text-2xl font-bold text-purple-600">$1,234.56</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Referrals;