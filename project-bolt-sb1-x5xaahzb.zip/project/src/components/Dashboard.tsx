import React from 'react';
import { TrendingUp, Users, DollarSign, PlayCircle } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string;
  change: string;
  icon: React.ReactNode;
}

interface InvestmentCardProps {
  title: string;
  risk: string;
  return: string;
  min: string;
  image: string;
}

const Dashboard = () => {
  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Investment"
          value="$24,500"
          change="+12.5%"
          icon={<TrendingUp className="w-6 h-6 text-green-600" />}
        />
        <StatCard
          title="Network Size"
          value="156"
          change="+8 this week"
          icon={<Users className="w-6 h-6 text-blue-600" />}
        />
        <StatCard
          title="Earnings"
          value="$1,245"
          change="+$245 today"
          icon={<DollarSign className="w-6 h-6 text-yellow-600" />}
        />
        <StatCard
          title="Ad Views"
          value="45/50"
          change="Daily quota"
          icon={<PlayCircle className="w-6 h-6 text-purple-600" />}
        />
      </div>

      {/* Investment Opportunities */}
      <div className="bg-white rounded-lg shadow">
        <div className="p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Investment Opportunities</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <InvestmentCard
              title="Conservative Fund"
              risk="Low"
              return="8-12% APY"
              min="$500"
              image="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=500"
            />
            <InvestmentCard
              title="Growth Fund"
              risk="Medium"
              return="15-20% APY"
              min="$1,000"
              image="https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?auto=format&fit=crop&w=500"
            />
            <InvestmentCard
              title="Aggressive Fund"
              risk="High"
              return="25-35% APY"
              min="$2,500"
              image="https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?auto=format&fit=crop&w=500"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard: React.FC<StatCardProps> = ({ title, value, change, icon }) => (
  <div className="bg-white rounded-lg shadow p-6">
    <div className="flex items-center justify-between">
      <div>
        <p className="text-sm font-medium text-gray-600">{title}</p>
        <p className="text-2xl font-semibold text-gray-900 mt-1">{value}</p>
        <p className="text-sm text-green-600 mt-1">{change}</p>
      </div>
      <div className="bg-gray-50 rounded-full p-3">{icon}</div>
    </div>
  </div>
);

const InvestmentCard: React.FC<InvestmentCardProps> = ({ title, risk, return: returnValue, min, image }) => (
  <div className="bg-white border border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
    <img src={image} alt={title} className="w-full h-40 object-cover" />
    <div className="p-4">
      <h3 className="text-lg font-medium text-gray-900">{title}</h3>
      <div className="mt-2 space-y-1">
        <p className="text-sm text-gray-600">Risk Level: {risk}</p>
        <p className="text-sm text-gray-600">Expected Return: {returnValue}</p>
        <p className="text-sm text-gray-600">Min Investment: {min}</p>
      </div>
      <button className="mt-4 w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors">
        Invest Now
      </button>
    </div>
  </div>
);

export default Dashboard;