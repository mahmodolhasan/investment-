import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Link, useLocation } from 'react-router-dom';
import { BarChart3, Users, PlaySquare, Gift, PieChart, Settings as SettingsIcon } from 'lucide-react';
import { useAuthStore } from './store/authStore';
import Navbar from './components/Navbar';
import Dashboard from './components/Dashboard';
import Network from './components/Network';
import AdCenter from './components/AdCenter';
import Referrals from './components/Referrals';
import Settings from './components/Settings';
import Login from './components/Login';

const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, loading } = useAuthStore();
  const location = useLocation();

  if (loading) {
    return <div>Loading...</div>;
  }

  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return <>{children}</>;
};

const App: React.FC = () => {
  const { user, loading, checkUser } = useAuthStore();

  useEffect(() => {
    checkUser();
  }, [checkUser]);

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <Router>
      <Routes>
        <Route path="/login" element={!user ? <Login /> : <Navigate to="/dashboard" replace />} />
        <Route
          path="/*"
          element={
            <ProtectedRoute>
              <Layout />
            </ProtectedRoute>
          }
        />
      </Routes>
    </Router>
  );
};

const Layout: React.FC = () => {
  const location = useLocation();

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="flex">
        {/* Sidebar */}
        <aside className="hidden md:flex flex-col w-64 bg-white border-r border-gray-200 min-h-screen p-4">
          <nav className="space-y-2">
            <Link
              to="/dashboard"
              className={`flex items-center space-x-3 px-4 py-3 rounded-lg ${
                isActive('/dashboard')
                  ? 'text-blue-600 bg-blue-50'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <BarChart3 className="w-5 h-5" />
              <span className="font-medium">Dashboard</span>
            </Link>
            <Link
              to="/network"
              className={`flex items-center space-x-3 px-4 py-3 rounded-lg ${
                isActive('/network')
                  ? 'text-blue-600 bg-blue-50'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <Users className="w-5 h-5" />
              <span>Network</span>
            </Link>
            <Link
              to="/ad-center"
              className={`flex items-center space-x-3 px-4 py-3 rounded-lg ${
                isActive('/ad-center')
                  ? 'text-blue-600 bg-blue-50'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <PlaySquare className="w-5 h-5" />
              <span>Ad Center</span>
            </Link>
            <Link
              to="/referrals"
              className={`flex items-center space-x-3 px-4 py-3 rounded-lg ${
                isActive('/referrals')
                  ? 'text-blue-600 bg-blue-50'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <Gift className="w-5 h-5" />
              <span>Referrals</span>
            </Link>
            <Link
              to="/investments"
              className={`flex items-center space-x-3 px-4 py-3 rounded-lg ${
                isActive('/investments')
                  ? 'text-blue-600 bg-blue-50'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <PieChart className="w-5 h-5" />
              <span>Investments</span>
            </Link>
            <Link
              to="/settings"
              className={`flex items-center space-x-3 px-4 py-3 rounded-lg ${
                isActive('/settings')
                  ? 'text-blue-600 bg-blue-50'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <SettingsIcon className="w-5 h-5" />
              <span>Settings</span>
            </Link>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6">
          <Routes>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/network" element={<Network />} />
            <Route path="/ad-center" element={<AdCenter />} />
            <Route path="/referrals" element={<Referrals />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </main>
      </div>
    </div>
  );
};

export default App;